<?php
/*
Plugin Name: NEX-Forms ADD ON - Shorcode Processor
Plugin URI: http://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix
Description: Run your own custom shorcode or 3rd party plugin shorcode anywhere in your forms. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.5.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/

if ( ! defined( 'ABSPATH' ) ) exit;
if(!class_exists('NEXForms_Shortcode_Processor'))
	{
	class NEXForms_Shortcode_Processor
		{
		public function process_shortcodes($content){

			$content = str_replace('\\','',$content);
			
			preg_match_all( '/'. get_shortcode_regex() .'/s', $content, $matches );
	
			$block_array = array();
			$i = 0;
			
			foreach($matches[0] as $match)
				{
				$block_array[$i] = $match;
				$i++;
				}
		
			foreach($block_array as $att_key=>$att_val)
				{
				$content = str_replace($att_val,do_shortcode( $att_val ),$content);	
				}
		$content = strip_shortcodes($content);
		return $content;
		}
	}
}

function nf_not_found_notice_sp() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>Shorcode Processor Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=sp">NEX-Forms - The Ultimate WordPress Form Builder</a>  OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_sp' );