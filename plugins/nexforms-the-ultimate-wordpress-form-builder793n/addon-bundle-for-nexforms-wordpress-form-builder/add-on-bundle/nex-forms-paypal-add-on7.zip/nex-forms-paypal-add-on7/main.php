<?php
/*
Plugin Name: NEX-Forms ADD ON - PayPal Classic
Plugin URI: http://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix
Plugin Prefix: wap_ 
Module Ready: Yes
Plugin TinyMCE: popup
Description: Enable paypal payments for NEX-Forms.  <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/

/***************************************/
/**********  Configuration  ************/
/***************************************/

if(isset($_POST['payment_status']))
		{
		global $wpdb;
		
		$data_array = array();
		$i=1;
		foreach($_POST as $key=>$val)
			{
			$data_array[] = array('field_name'=>$key,'field_value'=>$val);
			$i++;	
			}
		$update = $wpdb->update ( $wpdb->prefix . 'wap_nex_forms_entries', array('payment_status'=>$_POST['payment_status'], 'paypal_data'=>json_encode($data_array)), array(	'paypal_invoice' => $_POST['invoice']) );
		}

class NEXForms_PayPal_Config{
	/*************  General  ***************/
	/************  DONT EDIT  **************/
	public $plugin_version;
	/* The displayed name of your plugin */
	public $plugin_name;
	/* The alias of the plugin used by external entities */
	public $plugin_alias;
	/* Enable or disable external modules */
	public $enable_modules;
	/* Plugin Prefix */
	public $plugin_prefix;
	/* Plugin table */
	public $plugin_table, $component_table;
	/* Admin Menu */
	public $plugin_menu;
	/* Add TinyMCE */
	public $add_tinymce;
	
	
	/************* Database ****************/
	/* Sets the primary key for table created above */
	public $plugin_db_primary_key = 'Id';
	/* Database table fields array */
	public $plugin_db_table_fields = array
			(
			'nex_forms_Id'						=>	'text',
			'currency_code'						=>  'text',
			'products'							=>  'longtext',
			'business'							=>  'text',
			'cmd'								=>  'text',
			'return_url'						=>  'text',
			'cancel_url'						=>  'text',
			'lc'								=>  'text',
			'environment'						=>  'text'
			);
	
	
	
	
	public function __construct()
		{
		$this->plugin_version 	= 'PayPal for NEX-Forms';
		$this->plugin_name 		= '1.0';
		$this->plugin_prefix	= 'wap_';
		}
}

/***************************************/
/*************  Hooks   ****************/
/***************************************/
/* On plugin activation */
register_activation_hook(__FILE__, 'NEXForms_PayPal_run_instalation' );
/* Called on plugin activation */
function NEXForms_PayPal_run_instalation(){
	$config = new NEXForms_PayPal_Config();
	global $wpdb;
	
	/*$instalation = new NF5_Instalation();
	$instalation->component_name 			=  $config->plugin_name;
	$instalation->component_prefix 			=  $config->plugin_prefix;
	$instalation->component_alias			=  'nex_forms_paypal';
	$instalation->component_default_fields	=  $config->default_fields;
	$instalation->db_table_fields			=  $config->plugin_db_table_fields;
	$instalation->db_table_primary_key		=  $config->plugin_db_primary_key;
	$instalation->run_instalation('db');
	
	NF5_Database_Actions::alter_plugin_table('wap_nex_forms_paypal','cancel_url','text');*/
}


function nf_not_found_notice_pp() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>PayPal Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=ppc">NEX-Forms - The Ultimate WordPress Form Builder</a>  OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_pp' );

?>
