<?php
/*
Plugin Name: NEX-Forms ADD ON - Conditional Content Blocks
Plugin URI: http://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix
Description: Create dynamic content in emails and PDF's from submitted data. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.5.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/
add_shortcode( 'nfccb', 'NEXForms_setup_block_atts' );
if ( ! defined( 'ABSPATH' ) ) exit;
if(!class_exists('NEXForms_Conditional_Content'))
	{
	class NEXForms_Conditional_Content
		{
		public function run_content_logic_blocks($content){
			
			
			
			$content = str_replace('\\','',$content);
			
			preg_match_all( '/'. get_shortcode_regex() .'/s', $content, $matches );
	
			$block_array = array();
			$i = 0;
			
			
			
			foreach($matches[0] as $match)
				{
				$block_array[$i] = $match;
				$i++;
				}
		
			foreach($block_array as $att_key=>$att_val)
				{
					
				$email_block_atts = do_shortcode( $att_val );
				$sc_atts = json_decode( $email_block_atts,1);

				foreach($_REQUEST as $key=>$val)
					{
					if($key == str_replace('”','',$sc_atts['field']) && $val==str_replace('”','',$sc_atts['value']))
						{
						$content = str_replace($att_val,$matches[5][$att_key],$content);
						}
					}
				}
	
			$content = strip_shortcodes($content);
			return $content;
				
		}
	}
}


function NEXForms_setup_block_atts($atts) {

    extract(shortcode_atts(array(
        'field' => '',
		'value' => '',
   ), $atts));
return json_encode($atts,1);
}


function nf_not_found_notice_ccb() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>Conditional Content Blocks Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=ccb">NEX-Forms - The Ultimate WordPress Form Builder</a> OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_ccb' );
