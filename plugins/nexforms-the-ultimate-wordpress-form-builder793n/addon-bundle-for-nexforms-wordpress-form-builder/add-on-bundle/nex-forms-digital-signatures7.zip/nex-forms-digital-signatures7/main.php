<?php
/*
Plugin Name: NEX-Forms ADD ON - Digital Signatures
Plugin URI: http://codecanyon.net/user/basix/portfolio?ref=Basix
Description: Allows you to add digital signature fields to your forms. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/

function enqueue_nf_digital_sigs_scripts($hook) {
	wp_enqueue_script('nex-forms-signature',plugins_url('/js/nf-signature.js?v=7.5.11.2',__FILE__));
}
add_action( 'admin_enqueue_scripts', 'enqueue_nf_digital_sigs_scripts' );

/*add_action('admin_menu', 'NEXForms_ds_add_on_main_menu');

function NEXForms_ds_add_on_main_menu(){
	add_menu_page( 'NEX-Forms', 'NEX-Forms', $nf_user_level, 'nex-forms-dashboard', 'NEXForms_dashboard', plugins_url('/nf-admin/css/images/menu_icon.png',__FILE__) );
	add_submenu_page( 'nex-forms-dashboard', 'NF-Builder','Builder', $nf_user_level, 'nex-forms-builder', 'NEXForms_form_add_ons_page');
}*/

function nf_not_found_notice_ds() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>Digital Signatures Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=ds">NEX-Forms - The Ultimate WordPress Form Builder</a>  OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_ds' );