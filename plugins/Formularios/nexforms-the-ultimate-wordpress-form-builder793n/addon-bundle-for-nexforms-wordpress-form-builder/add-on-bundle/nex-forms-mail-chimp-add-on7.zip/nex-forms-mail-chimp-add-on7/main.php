<?php
/*
Plugin Name: NEX-Forms ADD ON - Mailchimp
Plugin URI: http://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix
Description: Automatically update your MailChimp lists with new subscribers from NEX-Forms. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.5.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/
add_action( 'wp_ajax_reload_mc_list', 'nexforms_mc_get_lists');
add_action( 'wp_ajax_reload_mc_form_fields', 'nexforms_mc_get_form_fields');


function nexforms_mc_test_api()
	{
		$key = '682b3cfee89942c79c3320ab7720b313-us14';
		//require_once('MailChimp.php');
		$mailchimp = new MailChimp($key);
		$ping = $mailchimp->call('helper/ping');
		if ($ping)
			{
			echo json_encode(array('success'=>'true'));
			die();
			}
		else
			{
			echo json_encode(array('failed'=>'true'));
			die();
			}
	}
	
function nexforms_mc_get_lists($form_id=0, $list_Id=0)
	{
		
		global $wpdb;
		$key = get_option('nex_forms_mailchimp_api_key');
		if(!$key){
			$output .= '<div class="alert alert-danger">No API key found.<br /><br />Please enter your Mailchimp API key from the Edit menu. Email Subscription->Mailchimp Config</div>';	
			return $output;
		}
		require_once('class.mailchimp.php');
		$mailchimp = new NEXForms_Mailchimp($key);
		$lists = $mailchimp->call('lists/list');
		
		$output = '';
		$active_subscriptions = array();
		$email_subcription = 0;
		$mc_list_id = 0;
		
		if ($lists)
			{
			
			if($form_id)
				{
			
				$get_form = $wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'wap_nex_forms WHERE Id = %d ',$form_id);
				$form_attr = $wpdb->get_row($get_form);
				
				$active_subscriptions = explode(',',$form_attr->email_subscription);
				$email_subcription = $form_attr->email_subscription;
				
				$mc_list_id = $form_attr->mc_list_id;
			
				}
			$output .= '<div class="row">';
													$output .= '<div class="col-sm-4 integration_form_label">';
														$output .= 'Integrate with Mailchimp';
													$output .= '</div>';
			$output .= '<div class="col-sm-8 integration_form_field no_input tour_mc_setup_1">';
				$output .= '
							
								<input id="mc_intergrate_yes" class="with-gap" type="radio" value="1" '.((in_array('mc',$active_subscriptions)) || ($email_subcription=='1') ? 'checked="checked"': '').' name="mc_integration">
								<label for="mc_intergrate_yes">Yes</label>
							
							
								<input id="mc_intergrate_no" class="with-gap" type="radio" value="0" '.((!in_array('mc',$active_subscriptions) || $email_subcription=='0') ? 'checked="checked"': '').'  name="mc_integration">
								<label for="mc_intergrate_no">No</label>
							
				';
			$output .= '</div>';
			$output .= '</div>';
				$output .= '<div class="row">
							<div class="col-sm-4 integration_form_label">Select List</div>
							<div class="col-sm-8 integration_form_field zero_padding tour_mc_setup_2">';	
		
		
		
			$output .= '<select name="mail_chimp_lists" class="form-control" data-selected="'.$mc_list_id.'">';
			$count_lists = 0;
			$output .= '<option value="0" selected="selected">--- Select List ---</option>';
				
			foreach($lists['data'] as $lists)
				{
				$output .= '<option value="'.$lists['id'].'" '.(($mc_list_id==$lists['id']) ? 'selected="selected"' : '').'>'.$lists['name'].'</option>';
				$count_lists ++;
				}
			$output .= '</select>';
			$output .= '</div>';
			$output .= '</div>';
			}
		else
			{
			$output .= '<div class="alert alert-danger">No list found. Please make sure your API key is correct:'.$key.'</div>';
			}
		if($count_lists==0)
			$output .= '<br /><br /><div class="alert alert-danger">No list found. <br /><br />Please make sure your API key is correct:<br /><br />'.$key.'</div>';
		
		$reload_mc_list = (isset($_POST['reload_mc_list'])) ? $_POST['reload_mc_list'] : '';
			
		if($reload_mc_list)
			{
			echo $output; 
			die();
			}
		else
			return $output;
	}

function nexforms_mc_get_form_fields($form_Id=0, $list_Id=0)
	{
		global $wpdb;
		
		$form_Id = (isset($_POST['form_Id'])) ? $_POST['form_Id'] : $form_Id;
		
		$key = get_option('nex_forms_mailchimp_api_key');
		$id = 0;
		$raw_mapped_fields = '';
		if($form_Id)
			{
			$get_form = $wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'wap_nex_forms WHERE Id = %d ',filter_var($form_Id,FILTER_SANITIZE_NUMBER_INT));
	
			$form_attr = $wpdb->get_row($get_form);
			
			$id = (isset($_POST['mc_list_id'])) ? $_POST['mc_list_id'] : $form_attr->mc_list_id;
			
			$raw_mapped_fields = explode('[end]',$form_attr->mc_field_map);
			
			}
	
		require_once('class.mailchimp.php');
		$mailchimp = new NEXForms_Mailchimp($key);
		$form_fields = $mailchimp->call('lists/merge-vars', array('apiKey'=>$key,'id'=>array($id)));
		
		$output = '';
		

		
		$mc_field_map = array();
		if($raw_mapped_fields)
			{
			foreach($raw_mapped_fields as $raw_mapped_field)
				{
				$mapped_field_array = 	explode('[split]',$raw_mapped_field);
				if($mapped_field_array[0])
					$mc_field_map[$mapped_field_array[0]] = $mapped_field_array[1];
				}
			}
		
		
		if ($id)
			{
			foreach($form_fields['data'][0]['merge_vars'] as $field)
				{
				$output .= '<div class="row mc-form-field" data-field-tag="'.$field['tag'].'">';
					$output .= '<div class="col-sm-4 integration_form_label">';
						$output .= $field['name'];
					$output .= '</div>';
					$output .= '<div class="col-sm-8 integration_form_field zero_padding">';
						$output .= '<select name="mc_current_fields" class="form-control" data-selected="'.$mc_field_map[$field['tag']].'">';
						$output .= '</select>';
					$output .= '</div>';
				$output .= '</div>';
				}
			}
		else
			{
			$output .= '<div class="alert alert-danger">No form found for selected list.</div>';
			
			}
		
		$reload_mc_list = (isset($_POST['reload_mc_list'])) ? $_POST['reload_mc_list'] : '';
			
		if($reload_mc_list)
			{
			echo $output; 
			die();
			}
		else
			return $output;
		
	}
function nexforms_mc_subscribe($mc_field_map,$mc_list_id, $data){
			
			$key = get_option('nex_forms_mailchimp_api_key');
			
			
			require_once('class.mailchimp.php');
			$mailchimp = new NEXForms_Mailchimp($key);
			
			foreach($mc_field_map as $key=>$val)
				{
				if(	$key=='EMAIL')
					$set_email['email']=$data[$val];
				else
					$merge_vars[$key]=$data[$val];
				}
			$result = $mailchimp->call('lists/subscribe', 
					array(
							'id'=>$mc_list_id,
							'email'=>$set_email,
							'merge_vars'=> $merge_vars
						 	)
					
					);
			if ( isset($result['error']) )
			{
				echo '<div class="alert alert-danger"><strong>Mailchimp Error: </strong> '.$result['error'].'</div>'; 
			}
			else
			{
				
			}
}

function nf_not_found_notice_mc() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>MailChimp Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=mc">NEX-Forms - The Ultimate WordPress Form Builder</a>  OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_mc' );


