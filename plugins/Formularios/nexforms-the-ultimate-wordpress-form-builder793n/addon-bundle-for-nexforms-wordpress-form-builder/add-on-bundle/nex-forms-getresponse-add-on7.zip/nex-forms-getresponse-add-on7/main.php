<?php
/*
Plugin Name: NEX-Forms ADD ON - GetRepsonse
Plugin URI: http://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix
Description: Automatically update your GetResponse lists with new subscribers from NEX-Forms. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.5.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/
add_action( 'wp_ajax_reload_gr_list', 'nexforms_gr_get_lists');
add_action( 'wp_ajax_reload_gr_form_fields', 'nexforms_gr_get_form_fields');


function nexforms_gr_test_api()
	{
		$key = '682b3cfee89942c79c3320ab7720b313-us14';
		//require_once('MailChimp.php');
		$getresponse = new MailChimp($key);
		$ping = $getresponse->call('helper/ping');
		if ($ping)
			{
			echo json_encode(array('success'=>'true'));
			die();
			}
		else
			{
			echo json_encode(array('failed'=>'true'));
			die();
			}
	}
	
function nexforms_gr_get_lists($form_Id=0, $list_Id=0)
	{
		if(!$form_Id)
			return;
			
		global $wpdb;
		$key = get_option('nex_forms_get_response_api_key');
		if(!$key){
			$output .= '<div class="alert alert-danger">No API key found.<br /><br />Please enter your GetReponse API key from Dashboard->Global Settings->GetReponse</div>';	
			return $output;
		}
		require_once('class.getresponse.php');
		$getresponse = new NEXForms_Getresponse($key);
		$lists = $getresponse->getCampaigns();
		
		$output = '';
		
		$active_subscriptions = array();
		$email_subcription = 0;
		$gr_list_id = 0;
		
		if ($lists)
			{
			
			if($form_Id)
				{
			
				$get_form = $wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'wap_nex_forms WHERE Id = %d ',$form_Id);
				$form_attr = $wpdb->get_row($get_form);
				
				$active_subscriptions = explode(',',$form_attr->email_subscription);
				$email_subcription = $form_attr->email_subscription;
				
				$gr_list_id = $form_attr->gr_list_id;
			
				}
		
			
			$output .= '<div class="row">';
				$output .= '<div class="col-sm-4 integration_form_label">';
					$output .= 'Integrate with GetResponse';
				$output .= '</div>';
			$output .= '<div class="col-sm-8 integration_form_field no_input tour_gr_setup_1">';
				$output .= '
							<input id="gr_intergrate_yes" class="with-gap" type="radio" value="1" '.((in_array('gr',$active_subscriptions)) ? 'checked="checked"': '').' name="gr_integration">
								
							<label for="gr_intergrate_yes">Yes</label>
							
								<input id="gr_intergrate_no" class="with-gap" type="radio" value="0" '.((!in_array('gr',$active_subscriptions)) ? 'checked="checked"': '').'  name="gr_integration">
								<label for="gr_intergrate_no">No</label>
				';
			$output .= '</div>';
			$output .= '</div>';
				$output .= '<div class="row">
							<div class="col-sm-4 integration_form_label">Select List</div>
							<div class="col-sm-8 integration_form_field zero_padding tour_gr_setup_2">';	
		
		
		
			$output .= '<select name="get_response_lists" class="form-control" data-selected="'.$gr_list_id.'">';
			$count_lists = 0;
			$output .= '<option value="0" selected="selected">--- Select List ---</option>';
				
			foreach($lists as $key=>$list)
				{
				$output .= '<option value="'.$key.'" '.(($gr_list_id==$key) ? 'selected="selected"' : '').'>'.$list->name.'</option>';
				$count_lists ++;
				}
			$output .= '</select>';
			$output .= '</div>';
			$output .= '</div>';
			}
		else
			{
			$output .= '<div class="alert alert-danger">No list found. Please make sure your API key is correct:'.$key.'</div>';
			}
		if($count_lists==0)
			$output .= '<br /><br /><div class="alert alert-danger">No list found. <br /><br />Please make sure your API key is correct:<br /><br />'.$key.'</div>';
			
		$reload_gr_list = (isset($_POST['reload_gr_list'])) ? $_POST['reload_gr_list'] : '';
		
		if($reload_gr_list)
			{
			echo $output; 
			die();
			}
		else
			return $output;
	}

function nexforms_gr_get_form_fields($form_Id=0, $list_Id=0)
	{
		if(!$form_Id)
			return;
		global $wpdb;
		
		$form_Id = (isset($_POST['form_Id'])) ? $_POST['form_Id'] : $form_Id;
		
		$key = get_option('nex_forms_get_response_api_key');
		$id = 0;
		$raw_mapped_fields = '';
		
		if($form_Id)
			{
			$get_form = $wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'wap_nex_forms WHERE Id = %d ',filter_var($form_Id,FILTER_SANITIZE_NUMBER_INT));
	
			$form_attr = $wpdb->get_row($get_form);
			
			$id = (isset($_POST['mc_list_id'])) ? $_POST['mc_list_id'] : $form_attr->gr_list_id;
			
			$raw_mapped_fields = explode('[end]',$form_attr->gr_field_map);
			
			}
		
		require_once('class.getresponse.php');
		$getresponse = new NEXForms_Getresponse($key);
		$form_fields = array();
		$form_fields[] = array('id'=>'name','name'=>'Name');
		$form_fields[] = array('id'=>'email','name'=>'Email');
		$custom = $getresponse->getAccountCustoms();
		foreach ($custom as $key => $value) {
			$form_fields[] = array('id'=>$key,'name'=>$value->name);
		}
		
		$output = '';
		

		
		$gr_field_map = array();
		if($raw_mapped_fields)
			{
			foreach($raw_mapped_fields as $raw_mapped_field)
				{
				$mapped_field_array = 	explode('[split]',$raw_mapped_field);
				if($mapped_field_array[0])
					$gr_field_map[$mapped_field_array[0]] = $mapped_field_array[1];
				}
			}
		
		
		if ($form_fields)
			{
			
			foreach($form_fields as $key=>$val)
				{
				
				$field_id = (isset($val['id'])) ? $val['id'] : 0;
				$field_name = (isset($val['name'])) ? $val['name'] : '';
				
				$selected = (isset($gr_field_map[$field_id])) ? $gr_field_map[$field_id] : '';
				
				$output .= '<div class="row gr-form-field" data-field-tag="'.$field_id.'">';
					$output .= '<div class="col-sm-4 integration_form_label">';
						$output .= $field_name;
					$output .= '</div>';
					$output .= '<div class="col-sm-8 integration_form_field zero_padding">';
						$output .= '<select name="gr_current_fields" class="form-control" data-selected="'.$selected.'">';
						$output .= '</select>';
					$output .= '</div>';
				$output .= '</div>';
				}
			
			}
		else
			{
			$output .= '<div class="alert alert-danger">No fields found for selected list.</div>';
			
			}
		
		$reload_gr_list = (isset($_POST['reload_gr_list'])) ? $_POST['reload_gr_list'] : '';
		
		if($reload_gr_list)
			{
			echo $output; 
			die();
			}
		else
			return $output;
		
	}
function nexforms_gr_subscribe($gr_field_map,$gr_list_id, $data){
			
			$key = get_option('nex_forms_get_response_api_key');
			
			
			require_once('class.getresponse.php');
			$getresponse = new NEXForms_Getresponse($key);
			
			foreach($gr_field_map as $key=>$val)
				{
				if(	$key=='email')
					$setmail=$data[$val];
					
				else if($key=='name')
					$name=$data[$val];
					
				else
					$merge_vars[$key]=$data[$val];
				}
				
			
			$result = $getresponse->addContact(
				$gr_list_id, 
				$name, 
				$setmail, 
				'standard', 
				0);
				if ( isset($result->message) )
				{
				echo '<div class="alert alert-danger"><strong>GetResponse Error:</strong> '.$result->message.'</div>';
				//$result->message;
				//	$fc_final_response['debug']['failed'][] = "(".$list_submit['email'].")<br>".__($result->message,'formcraft-getresponse');
				}
				else
				{
				
				//	$fc_final_response['debug']['success'][] = 'GetResponse Added: '.$list_submit['email'];
				}
			
			
			

}

function nf_not_found_notice_gr() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>GetResponse Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=gr">NEX-Forms - The Ultimate WordPress Form Builder</a>  OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_gr' );
