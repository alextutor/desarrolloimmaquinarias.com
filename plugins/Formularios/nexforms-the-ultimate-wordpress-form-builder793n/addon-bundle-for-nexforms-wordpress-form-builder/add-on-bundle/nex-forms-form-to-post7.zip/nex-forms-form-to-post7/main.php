<?php
/*
Plugin Name: NEX-Forms ADD ON - Form to Post
Plugin URI: http://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix
Description: Automatically create posts or pages from NEX-Forms form submissions. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.5.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/
add_action( 'wp_ajax_nexforms_ftp_setup', 'nexforms_ftp_setup');
function nexforms_ftp_setup($form_Id){
	
	global $wpdb;
	
	$form_Id = (isset($_POST['form_Id'])) ? $_POST['form_Id'] : $form_Id;
	
	

	$form_to_post = 0;
	$raw_mapped_fields = 0;
	
	if($form_Id)
		{
		$get_form = $wpdb->prepare('SELECT * FROM '.$wpdb->prefix.'wap_nex_forms WHERE Id = %d ',filter_var($form_Id,FILTER_SANITIZE_NUMBER_INT));
		$form_attr = $wpdb->get_row($get_form);
		$raw_mapped_fields = explode('[end]',$form_attr->form_to_post_map);
		$form_to_post = $form_attr->is_form_to_post;
		}
	
	$ftp_field_map = array();
	if($raw_mapped_fields)
		{
		foreach($raw_mapped_fields as $raw_mapped_field)
			{
			$mapped_field_array = 	explode('[split]',$raw_mapped_field);
			if($mapped_field_array[0])
				$ftp_field_map[$mapped_field_array[0]] = $mapped_field_array[1];
			}
		}
	
	$output = '';
	
	/*echo '<div class="email_setup_wrapper">';
				
				echo '<div class="row last">';
					echo '<div class="integration_form_label" style="height: 57px">PDF Email Attachements</div>';
					
					echo '<div class="integration_form_field no_input" style="height: 57px">';
						echo '<input '.(in_array('admin',$pdf_attach) ? 'checked="checked"': '').' name="pdf_admin_attach" value="1" id="pdf_admin_attach" type="checkbox"><label for="pdf_admin_attach">Attach this PDF to Admin Notifications Emails<em></em></label>';
						echo '<br /><input '.(in_array('user',$pdf_attach) ? 'checked="checked"': '').' name="pdf_user_attach" value="1" id="pdf_user_attach" type="checkbox"><label for="pdf_user_attach">Attach this PDF to Autoresponder User Emails<em></em></label>';
					echo '</div>';
				echo '</div>';
				echo '<div class="row">';
					echo '<div class="editor_wrapper">';
						wp_editor( (($this->pdf_html) ? str_replace('\\','',$this->pdf_html) : '' ), 'pdf_html');		
					echo '</div>';
				echo '</div>';
			echo '</div>';*/
	
	echo '<div class="ftp_reponse_setup email_setup_wrapper">';
											
		echo '<div class="row">';
			echo '<div class="integration_form_label">';
				echo 'Integrate with Form to Post';
			echo '</div>';
			echo '<div class="integration_form_field no_input tour_ftp_setup_1">';
			echo '
						
							<input id="ftp_intergrate_yes" class="with-gap" type="radio" value="1" '.(($form_to_post=='1') ? 'checked="checked"' : '').' name="ftp_integration">
							<label for="ftp_intergrate_yes">Yes</label>
						
							<input id="ftp_intergrate_no" class="with-gap" type="radio" value="0" '.(($form_to_post=='0') ? 'checked="checked"' : '').'  name="ftp_integration">
							<label for="ftp_intergrate_no">No</label>
						
			';
			echo '</div>';
		echo '</div>';
	
	$ftp_post_type 				= (isset($ftp_field_map['post_type'])) ? $ftp_field_map['post_type'] : 'post';
	$ftp_post_status 			= (isset($ftp_field_map['post_status'])) ? $ftp_field_map['post_status'] : 'pending';
	$ftp_comment_status 		= (isset($ftp_field_map['comment_status'])) ? $ftp_field_map['comment_status'] : 'open';
	$ftp_post_content	 		= (isset($ftp_field_map['post_content'])) ? $ftp_field_map['post_content'] : '';
	$ftp_post_title	 			= (isset($ftp_field_map['post_title'])) ? $ftp_field_map['post_title'] : '';
	$ftp_post_featured_image	= (isset($ftp_field_map['post_featured_image'])) ? $ftp_field_map['post_featured_image'] : '';
	
	
	
	
	
	echo '<div class="row ftp-form-field" data-field-tag="post_title">';
		echo '<div class="integration_form_label">';
					
				echo 'Post Title';
		echo '</div>';
		echo '<div class="integration_form_field tour_ftp_setup_2">';
			echo '<select name="ftp_current_fields" class="form-control" data-selected="'.$ftp_post_title.'">';
			echo '</select>';
		echo '</div>';
	echo '</div>';
	
	
	

	echo '<div class="row ftp-form-field" data-field-tag="post_featured_image">';
		echo '<div class="integration_form_label">';
			echo 'Featured Image';
		echo '</div>';
		echo '<div class="integration_form_field tour_ftp_setup_3">';
			echo '<select name="ftp_current_fields" class="form-control" data-selected="'.$ftp_post_featured_image.'">';
			echo '</select>';
		echo '</div>';
	echo '</div>';
	
	echo '<div class="row ftp-attr" data-field-tag="post_type">';
					echo '<div class="integration_form_label">';
						echo 'Type';
					echo '</div>';
					echo '<div class="integration_form_field tour_ftp_setup_4">';
						echo '<select name="ftp_attr_fields" class="form-control" data-selected="'.$ftp_post_type.'">';
							echo '<option value="post" '.(($ftp_post_type=='post') ? 'selected="selected"' : '').'>Post</option>';
							echo '<option value="page" '.(($ftp_post_type=='page') ? 'selected="selected"' : '').'>Page</option>';
						echo '</select>';
					echo '</div>';
				echo '</div>';
	
	echo '<div class="row ftp-attr" data-field-tag="post_status">';
					echo '<div class="integration_form_label">';
						echo 'After submit set post as:';
					echo '</div>';
					echo '<div class="integration_form_field tour_ftp_setup_5">';
						echo '<select name="ftp_attr_fields" class="form-control" data-selected="'.$ftp_post_status.'">';
							echo '<option value="pending" '.(($ftp_post_status=='pending') ? 'selected="selected"' : '').'>Pending Review</option>';
							echo '<option value="publish" '.(($ftp_post_status=='publish') ? 'selected="selected"' : '').'>Published</option>';
							echo '<option value="draft" '.(($ftp_post_status=='draft') ? 'selected="selected"' : '').'>Draft</option>';
							echo '<option value="private" '.(($ftp_post_status=='private') ? 'selected="selected"' : '').'>Private</option>';
						echo '</select>';
					echo '</div>';
				echo '</div>';
	
	echo '<div class="row ftp-attr" data-field-tag="comment_status">';
					echo '<div class="integration_form_label ">';
						echo 'Allow Comments';
					echo '</div>';
					echo '<div class="integration_form_field tour_ftp_setup_6">';
						echo '<select name="ftp_attr_fields" class="form-control" data-selected="'.$ftp_comment_status.'">';
							echo '<option value="open" '.(($ftp_comment_status=='open') ? 'selected="selected"' : '').'>Open</option>';
							echo '<option value="closed" '.(($ftp_comment_status=='closed') ? 'selected="selected"' : '').'>Closed</option>';
						echo '</select>';
					echo '</div>';
				echo '</div>';
	
	
	echo '<div class="row ftp-form-field" data-field-tag="post_content">';
		echo '<div class="integration_form_label">';
					
				echo 'Post Content';
		echo '</div>';
		echo '<div class="integration_form_field no_input" style="background:#f2f8fd; border-left:none">';
			//echo '<select name="ftp_current_fields" class="form-control" data-selected="'.$ftp_post_content.'">';
			//echo '</select>';
			
			
		echo '</div>';
	echo '</div>';
	
	echo '<div class="row">';
		echo '<div class="editor_wrapper">';
			wp_editor(str_replace('\\','',$ftp_post_content), 'ftp_content');
		echo '</div>';
	echo '</div>';	
	
	
	echo '</div>';
	
	$ajax = (isset($_POST['form_Id'])) ? 1 : 0;
	
	if($ajax)
		{
		//echo $output; 
		die();
		}
	else
		return $output;
}

function nf_not_found_notice_ftp() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>Form to POST/PAGE Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=ftp">NEX-Forms - The Ultimate WordPress Form Builder</a> OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_ftp' );

