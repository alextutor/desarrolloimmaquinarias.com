<?php
// Include the main TCPDF library (search for installation path).
function NEXForms_export_to_PDF($entry_ID, $save=false, $ajax=false, $attach=false){
	
	$nf_functions = new NEXForms_Functions();
	$database_actions = new NEXForms_Database_Actions();
	if(!$save)
		{
		$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
		require_once( $parse_uri[0] . 'wp-load.php' );
		require_once('tcpdf_include.php');
		}

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);


global $wpdb;
			$form_entry = $wpdb->get_row('SELECT * FROM '.$wpdb->prefix.'wap_nex_forms_entries WHERE Id="'.$entry_ID.'"');
			$form_attr = $wpdb->get_row('SELECT * FROM '.$wpdb->prefix.'wap_nex_forms WHERE Id="'.$form_entry->nex_forms_Id.'"');

// set document information
/*$pdf->SetCreator($database_actions->get_username($form_entry->user_Id));
$pdf->SetAuthor($database_actions->get_username($form_entry->user_Id));
$pdf->SetTitle($database_actions->get_title($form_entry->nex_forms_Id,'wap_nex_forms'));
$pdf->SetSubject();
$pdf->SetKeywords();*/


$date_time = explode(' ',$form_entry->date_time);

$date = explode('-', $date_time[0]);
$time = explode(':', $date_time[1]);

/*$set_header = 'Submitted by '.(($database_actions->get_username($form_entry->user_Id)) ? $database_actions->get_username($form_entry->user_Id) : 'Guest').' '.(($form_entry->date_time) ? 'on '.date(get_option('date_format'),mktime($time[0],$time[1],$time[2],$date[1],$date[3],$date[0])) : '');
$set_header .= '
From page: '.$form_entry->page;
$set_header .= '
From IP: '.$form_entry->ip;*/
// set default header data
//$pdf->SetHeaderData('', '0', $database_actions->get_title($form_entry->nex_forms_Id,'wap_nex_forms').'', $set_header);

// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
//$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/pol.php')) {
	require_once(dirname(__FILE__).'/lang/pol.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('freesans','',10);
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);

//$pdf->SetFont('nanumbarungothicyethangul','',10);

// add a page
$pdf->AddPage();

		$upload_path = wp_upload_dir();
		$set_uploads_dir = $upload_path['path'];
		
		//var_dump($upload_path);
			//echo str_replace('\\','',$form->form_fields);
			
			//echo 'test'.$_POST['form_entry_Id'];
			  $form_data = json_decode($form_entry->form_data);
			  
			 
			  $data_val_array = array();
			   foreach($form_data as $data)
					{
					$data_val_array[$data->field_name]=$data->field_value;
					}
			
			 /* echo '<pre>';
			  print_r($form_data);
			 echo '</pre>';*/
			
			 $html = '<table width="100%" cellpadding="3" cellspacing="0">';
			 
			 $img_ext_array = array('jpg','jpeg','png','tiff','gif','psd');
			 $sigs_array = array();
			 $i = 0;
			 foreach($form_data as $data)
					{
						if($data->field_name!='paypal_invoice')
							{
							$html .= '<tr>';
								$html .= '<td width="15%"><strong>'.$nf_functions->unformat_name($data->field_name).'</strong></td>';
								$html .= '<td width="2%"><strong>:</strong></td>';
								$html .= '<td width="83%">';
									if(is_array($data->field_value))
										{
										 foreach($data->field_value as $key=>$val)
											{
											$html .= '<span class="text-success fa fa-check"></span>&nbsp;&nbsp;'.$val.'<br />';
											}
										}
									else
										{
										if(strstr($data->field_value,'data:image'))
											{
											$signature = str_replace('data:image/png;base64,','',$data->field_value);
											$sig_rand = rand(0,99999);
											file_put_contents (plugin_dir_path(dirname(__FILE__)).'tmp/sig'.$sig_rand.'.png', base64_decode($signature));
												
											$html .= '<img width="200px" src="'.plugins_url('/tmp/sig'.$sig_rand.'.png',dirname(__FILE__)).'">';
											//$html .= $data->field_value;
											
											//$html .= ;
											$sigs_array[$i] = plugin_dir_path(dirname(__FILE__)).'tmp/sig'.$sig_rand.'.png';
											$i++;
											}
										else if(in_array($nf_functions->get_ext($data->field_value),$img_ext_array))
											$html .= '<img width="200px" src="'.$data->field_value.'">';
										else
											$html .= $data->field_value;
										}
							$html .= '</td>';
						$html .= '</tr>';
							}
							
					}
			 $html .= '</table>';
			 
			 $form_attr->pdf_html = str_replace('\\','',$form_attr->pdf_html);
			 
			 $body = str_replace('{{nf_form_data}}',$html,$form_attr->pdf_html);
			 
			 
			 
			$body = str_replace('{{nf_from_page}}',$form_entry->page,$body);
			$body = str_replace('{{nf_form_id}}',$form_entry->nex_forms_Id,$body);
			$body = str_replace('{{nf_entry_id}}',$entry_ID,$body);
			$body = str_replace('{{nf_entry_date}}',date('Y-m-d H:i:s'),$body);
			$body = str_replace('{{nf_user_ip}}',$form_entry->ip,$body);
			$body = str_replace('{{nf_form_title}}',$form_attr->title,$body);
			$body = str_replace('{{nf_user_name}}',$database_actions->get_username($form_entry->user_Id),$body);
			
			 
			 
			 
			 $pattern = '({{+([A-Za-z 0-9_])+}})';		
			 if(!$body)
			 	$body = $html;
	

	
	//SETUP VALUEPLACEHOLDER - USER EMAIL
	preg_match_all($pattern, $body, $matches);
		foreach($matches[0] as $match)
			{
			$the_val = '';
			if(is_array($data_val_array[$nf_functions->format_name($match)]))
				{
				foreach($data_val_array[$nf_functions->format_name($match)] as $thekey=>$value)
					{
					$the_val .='<span class="fa fa-check"></span> '. $value.' ';	
					}
				$the_val = str_replace('Array','',$the_val);
				$body = str_replace($match,$the_val,$body);
				}
			else if(strstr($data_val_array[$nf_functions->format_name($match)],'data:image'))
				{
				$signature = str_replace('data:image/png;base64,','',$data_val_array[$nf_functions->format_name($match)]);
				$sig_rand = rand(0,99999);
				file_put_contents (plugin_dir_path(dirname(__FILE__)).'tmp/sig'.$sig_rand.'.png', base64_decode($signature));
					
				$image = '<img width="200px" src="'.plugins_url('/tmp/sig'.$sig_rand.'.png',dirname(__FILE__)).'">';
				//$html .= $data->field_value;
				
				$body = str_replace($match,$image,$body);	
				
				//$html .= ;
				$sigs_array[$i] = plugin_dir_path(dirname(__FILE__)).'tmp/sig'.$sig_rand.'.png';
				$i++;
				}
			else
				{
				$body = str_replace($match,$data_val_array[$nf_functions->format_name($match)],$body);	
				}
			}
			 
//echo $body;
// create some HTML content
$database = new NEXForms_Database_Actions();
			
$body = ($database->checkout()) ? $body : 'Sorry, you need to register this plugin to export entries to PDF. Go to global settings on the dashboard and follow the registration procedure.';
				
// output the HTML content
$pdf->writeHTML($body, true, false, false, false, '');

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------
//Close and output PDF document

foreach($sigs_array as $sigs=>$val){
	unlink($val);
	}

if($attach)
	{
	$pdf->Output($set_uploads_dir.'/'.substr($nf_functions->format_name($database_actions->get_title2($form_entry->nex_forms_Id,'wap_nex_forms')),0,10).'_'.$form_entry->Id.'.pdf', 'F');
	echo $pdf->Output($set_uploads_dir.'/'.substr($nf_functions->format_name($database_actions->get_title2($form_entry->nex_forms_Id,'wap_nex_forms')),0,10).'_'.$form_entry->Id.'.pdf', 'F');
	}
if(!$save)
	{
	$pdf->Output($nf_functions->format_name($database_actions->get_title2($form_entry->nex_forms_Id,'wap_nex_forms')).'_'.$form_entry->Id.'.pdf', 'I');
	}
else
	{
	
	if($ajax)
		{
		$pdf->Output($set_uploads_dir.'/form_entry.pdf', 'F');
		echo $upload_path['baseurl'].$upload_path['subdir'].'/form_entry.pdf';
		die();
		}
	else
		{
		$pdf->Output($set_uploads_dir.'/'.substr($nf_functions->format_name($database_actions->get_title2($form_entry->nex_forms_Id,'wap_nex_forms')),0,10).'_'.$form_entry->Id.'.pdf', 'F');
		
		//echo $set_uploads_dir.'/'.$database_actions->get_title($form_entry->nex_forms_Id,'wap_nex_forms').'_'.$form_entry->Id.'.pdf';
		
		return $set_uploads_dir.'/'.substr($nf_functions->format_name($database_actions->get_title2($form_entry->nex_forms_Id,'wap_nex_forms')),0,10).'_'.$form_entry->Id.'.pdf';
		
		//return $set_uploads_dir.'/'.$database_actions->get_title($form_entry->nex_forms_Id,'wap_nex_forms').'_'.$form_entry->Id.'.pdf';
		}
	}
}
$entry_id = (isset($_REQUEST['entry_ID'])) ? $_REQUEST['entry_ID'] : '';
if($entry_id ){
	NEXForms_export_to_PDF($entry_id , false);
}


function NEXForms_report_to_PDF(){
		
		$nf_functions = new NEXForms_Functions();
		$database_actions = new NEXForms_Database_Actions();
		
		global $wpdb;
		
		$tmp_csv_export = get_option('tmp_csv_export');
		$get_sql = explode('LIMIT',$tmp_csv_export['query']);
		$sql = $get_sql[0];
		$cols = $tmp_csv_export['cols'];
		$get_form_data = $wpdb->prepare($sql,'');
		$form_data = $wpdb->get_results($get_form_data); 
		
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
			require_once(dirname(__FILE__).'/lang/eng.php');
			$pdf->setLanguageArray($l);
		}
		//$pdf->SetFont('helvetica', '', 9);
		$pdf->SetFont('helvetica','',9);
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
			
		$page_content = array();
		
		$table_fields 	= $wpdb->get_results('SHOW FIELDS FROM '.$wpdb->prefix.'wap_nex_forms_temp_report');
		
		$header = '<h1>Submissions report for <strong>'.$database_actions->get_title($tmp_csv_export['form_Id'],'wap_nex_forms').'</strong> on '.date(get_option('date_format')).'</h1><br /><br />&nbsp;';
		$header .= '<hr>';
		$header .= '<table width="100%" cellpadding="3" cellspacing="0" border="1">';
			
			$count_cols = 1;
			$header .= '<tr>';
			foreach($table_fields as $column)
				{
				if($column->Field!='Id')
					{
					if(is_array($cols))
						{
						if(in_array($column->Field,$cols))
							{
							$columns_array[$column->Field] = $column->Field;
							$header .= '<td><strong>'.$nf_functions->unformat_name($column->Field).'</strong></td>';
							$count_cols ++;
							}
						}
					else
						{
						$columns_array[$column->Field] = $column->Field;
						$header .= '<td><strong>'.$nf_functions->unformat_name($column->Field).'</strong></td>';
						$count_cols ++;
						}
					}
				
				}
		$header .= '</tr>';
		$header .= '<tbody>';
		
		$footer = '</tbody>';
		$footer .= '</table>';
			$i = 1;
			$pages = 1;
		$content = '';	
			$img_ext_array = array('jpg','jpeg','png','tiff','gif','psd');
			$i = 0;
			$sigs_array = array();
			foreach($form_data as $value)
				{
				$content .= '<tr>';
				foreach($columns_array as $column)
					{
					$content .= '<td>';
					$field_value = $value->$column;
					
					$field_value = str_replace('\r\n',' ',$field_value);
					$field_value = str_replace('\r',' ',$field_value);
					$field_value = str_replace('\n',' ',$field_value);
					$field_value = str_replace(',',' ',$field_value);
					$field_value = str_replace('
					',' ',$field_value);
					$field_value = str_replace('
					
					',' ',$field_value);
					$field_value = str_replace(chr(10),' ',$field_value);
					$field_value = str_replace(chr(13),' ',$field_value);
					$field_value = str_replace(chr(266),' ',$field_value);
					$field_value = str_replace(chr(269),' ',$field_value);
					$field_value = str_replace(chr(522),' ',$field_value);
					$field_value = str_replace(chr(525),' ',$field_value);
					
					
					if(strstr($field_value,'data:image'))
						{
						$signature = str_replace('data:image/png;base64 ','',$field_value);
						$sig_rand = rand(0,99999);
						file_put_contents (plugin_dir_path(dirname(__FILE__)).'tmp/sig'.$sig_rand.'.png', base64_decode($signature));
						$content .= '<img width="100px" src="'.plugins_url('/tmp/sig'.$sig_rand.'.png',dirname(__FILE__)).'">';
						$sigs_array[$i] = plugin_dir_path(dirname(__FILE__)).'tmp/sig'.$sig_rand.'.png';
						$i++;
						}
					else
						{
						if(in_array($nf_functions->get_ext($field_value),$img_ext_array))
							$content .= '<img width="65px" src="'.$field_value.'">';
						else
							$content .= $field_value;
						}
					$content .= '</td>';
					
					}
				
				
				$content .= '</tr>';
				$i++;
				if($i==30)
					{
					/*$pdf->AddPage('L', 'A4');
					$set_page_content = $header.$content.$footer;
					$pdf->writeHTML($set_page_content, true, false, true, false, '');
					//$pdf->lastPage();
					$content = '';
					$i = 1;*/
					}
				}
				
				
			
	
	

	$upload_path = wp_upload_dir();
	$set_uploads_dir = $upload_path['path'];
	
	$pdf->setPrintHeader(false);
	$pdf->setPrintFooter(false);
	
	$pdf->AddPage('L', 'A4');
	$set_page_content = $header.$content.$footer;
	$set_page_content = ($database_actions->checkout()) ? $set_page_content : 'Sorry, you need to register this plugin to export entries to PDF. Go to global settings on the dashboard and follow the registration procedure.';
	$pdf->writeHTML($set_page_content, true, false, true, false, '');

	$pdf->Output($set_uploads_dir.'/submission_report.pdf', 'F');
	echo $upload_path['baseurl'].$upload_path['subdir'].'/submission_report.pdf';
	
	foreach($sigs_array as $sigs=>$val){
	unlink($val);
	}
	
	die();
	}