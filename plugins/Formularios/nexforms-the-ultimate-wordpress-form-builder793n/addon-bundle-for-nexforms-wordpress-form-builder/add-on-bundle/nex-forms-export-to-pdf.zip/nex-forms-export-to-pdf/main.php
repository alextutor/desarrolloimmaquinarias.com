<?php
/*
Plugin Name: NEX-Forms ADD ON - PDF Creator
Plugin URI: http://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix
Description: Enables custom PDF creation from submmited form data. Also enabled these PDF's to be attached to admin and user emails. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.x</a></strong>.
Author: Basix
Version: 7.5.12.5
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/

require_once('examples/tcpdf_include.php');
require_once('examples/main.php');
require_once('tcpdf.php');

function nf_not_found_notice_pdf() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>PDF Creator Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=pdf">NEX-Forms - The Ultimate WordPress Form Builder</a>  OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_pdf' );