<?php
/*
Plugin Name: NEX-Forms ADD ON - PayPal PRO
Plugin URI: http://codecanyon.net/user/basix/portfolio?ref=Basix
Description: PayPal Pro for NEX-Forms enable online paypal payments and payment tracking. <strong>Requires at least: <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix" target="_blank" style="display:block">NEX-Forms v7.5.x</a></strong>
Author: Basix
Version: 7.5.12.1
Author URI: http://codecanyon.net/user/Basix/portfolio?ref=Basix
License: GPL
*/


require 'vendor/autoload.php';

function nf_get_paypal_payment($token){
	
	global $wpdb;
	
	$payment_entry = $wpdb->get_row('SELECT * FROM '. $wpdb->prefix .'wap_nex_forms_entries WHERE paypal_payment_token = "'.$token.'"');
	
	
	$form_details = $wpdb->get_row('SELECT * FROM '. $wpdb->prefix .'wap_nex_forms WHERE Id = "'.$payment_entry->nex_forms_Id.'"');

	if($form_details->environment!='sandbox')
		{
		$apiContext = new \PayPal\Rest\ApiContext(
				new \PayPal\Auth\OAuthTokenCredential(
					$form_details->paypal_client_Id,     	// ClientID
					$form_details->paypal_client_secret    // ClientSecret
				)
			);
		}
	else
		{
		$apiContext = new \PayPal\Rest\ApiContext(
				new \PayPal\Auth\OAuthTokenCredential(
					'AYSq3RDGsmBLJE-otTkBtM-jBRd1TCQwFf9RGfwddNXWz0uFU9ztymylOhRS',     // Sandbox ClientID
					'EGnHDxD_qRPdaLdZz8iCr8N7_MzF-YHPTkjs6NKYQvQSBngp4PTTVWkPZRbL'      // Sandbox ClientSecret
				)
			);
		}

	if($form_details->environment!='sandbox')
		{
			$apiContext->setConfig(
			  array(
				'mode' => 'live',
			  )
			);
		}

	$payment = new \PayPal\Api\Payment();
	try {
		$get_payment = $payment->get($payment_entry->paypal_payment_id, $apiContext);
		} 
	catch (Exception $ex) 
		{
		// NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY
		/*echo '<pre>';
		print_r( $payment_entry);
		echo '</pre>';*/
		exit(1);
		}
	$get_payment_status = $get_payment->getPayer();
		
		
		
   // $details = new Details();
		/*echo '<pre>';
		print_r($get_payment_status);
		echo '</pre>';*/
	
	
	
	$execution = new \PayPal\Api\PaymentExecution();
			$execution->setPayerId($_GET['PayerID']);
			
			$transaction = new \PayPal\Api\Transaction();
			$amount = new \PayPal\Api\Amount();
		   
			
			$amount->setCurrency($payment_entry->payment_currency);
			$amount->setTotal($payment_entry->payment_ammount);
		   // $amount->setDetails($details);
			$transaction->setAmount($amount);
			
			$execution->addTransaction($transaction);
			
	
			try 
				{
				$result = $get_payment->execute($execution, $apiContext);
				
				}
			catch (Exception $ex) 
				{
				echo '<pre class="nf_pre_class" style="display:none;">';
				print_r($ex);
				echo '</pre>';
				}
	
	
	if(is_object($get_payment_status))
		{
		if($get_payment_status->status=='VERIFIED')
			{
			$update = $wpdb->update ( $wpdb->prefix . 'wap_nex_forms_entries', array('paypal_data'=>json_encode($get_payment),'payment_status'=>'payed'), array(	'Id' => $payment_entry->Id ));
			return array('payment_verified'=>true,'entry_Id'=>$payment_entry->Id,'nex_forms_Id'=>$payment_entry->nex_forms_Id);
			}
		else
			{
			$update = $wpdb->update ( $wpdb->prefix . 'wap_nex_forms_entries', array('paypal_data'=>json_encode($get_payment),'payment_status'=>'failed'), array(	'Id' => $payment_entry->Id ));
			return array('payment_verified'=>false,'entry_Id'=>$payment_entry->Id,'nex_forms_Id'=>$payment_entry->nex_forms_Id);
			}
		}
	else
		{
		$update = $wpdb->update ( $wpdb->prefix . 'wap_nex_forms_entries', array('paypal_data'=>json_encode($get_payment),'payment_status'=>'failed'), array(	'Id' => $payment_entry->Id ));
		return array('payment_verified'=>false,'entry_Id'=>$payment_entry->Id,'nex_forms_Id'=>$payment_entry->nex_forms_Id);
		}
}


function run_nf_adv_paypal($form_Id=0, $form_data=array(), $return_url = ''){
	
	global $wpdb;
	if(!$form_Id)
		return 'ERROR: No form ID passed.';
		
	$do_get_result = $wpdb->prepare('SELECT * FROM '. $wpdb->prefix .'wap_nex_forms WHERE Id = %d',filter_var($form_Id,FILTER_SANITIZE_NUMBER_INT));
		
		$get_result = $wpdb->get_row($do_get_result);
		
		if(!$get_result->products)
			{
			$do_get_result = $wpdb->prepare('SELECT * FROM '. $wpdb->prefix .'wap_nex_forms_paypal WHERE nex_forms_Id = %d ',filter_var($form_Id,FILTER_SANITIZE_NUMBER_INT));
		
			$get_result = $wpdb->get_row($do_get_result);	
			}
	if($get_result->environment!='sandbox')
		{
		$apiContext = new \PayPal\Rest\ApiContext(
				new \PayPal\Auth\OAuthTokenCredential(
					$get_result->paypal_client_Id,     	// ClientID
					$get_result->paypal_client_secret    // ClientSecret
				)
			);
		}
	else
		{
		$apiContext = new \PayPal\Rest\ApiContext(
				new \PayPal\Auth\OAuthTokenCredential(
					'AYSq3RDGsmBLJE-otTkBtM-jBRd1TCQwFf9RGfwddNXWz0uFU9ztymylOhRS',     // ClientID
					'EGnHDxD_qRPdaLdZz8iCr8N7_MzF-YHPTkjs6NKYQvQSBngp4PTTVWkPZRbL'      // ClientSecret
				)
			);
		}

	if($get_result->environment!='sandbox')
		{
			$apiContext->setConfig(
			  array(
				'mode' => 'live',
			  )
			);
		}
	

	
	$payer = new \PayPal\Api\Payer();
	$payer->setPaymentMethod("paypal");


	//$i =0;
    $item  = array();
	$items = array();
	$index = 1;
	//JSON ARRAY
	/*$paypal_items = json_decode($get_result->products,true);
	
	$set_item_price = 0;
	$set_item_quantity = 0;
	
	foreach($paypal_items as $paypal_item)
		{
			if(!empty($paypal_item))
				{
				if($paypal_item['set_amount']=='map')
					$set_item_price = $form_data[$paypal_item['map_item_amount']];
				else
					$set_item_price = $paypal_item['item_amount'];
					
				if($paypal_item['set_quantity']=='map')
					$set_item_quantity = $form_data[$paypal_item['map_item_qty']];
				else
					$set_item_quantity = $paypal_item['item_qty'];
				
				
				$item[$index] = new \PayPal\Api\Item();
				$item[$index]->setName($paypal_item['item_name'])
						->setCurrency('USD')
						->setQuantity($set_item_quantity)
						//->setSku(rand(0,9999999)) // Similar to `item_number` in Classic API
						->setPrice($set_item_price);
				$items[] = $item[$index];
				$index++;
				}
			
		}*/
	
	$products = explode('[end_product]',$get_result->products);
		$i=1;
		$items = array();
		$item_total = 0;
		foreach($products as $product)
			{
			$item_name =  explode('[item_name]',$product);
			$item_name2 =  explode('[end_item_name]',$item_name[1]);

			$item_qty =  explode('[item_qty]',$product);
			$item_qty2 =  explode('[end_item_qty]',$item_qty[1]);
			
			$map_item_qty =  explode('[map_item_qty]',$product);
			$map_item_qty2 =  explode('[end_map_item_qty]',$map_item_qty[1]);
			
			$set_quantity =  explode('[set_quantity]',$product);
			$set_quantity2 =  explode('[end_set_quantity]',$set_quantity[1]);
			
			$item_amount =  explode('[item_amount]',$product);
			$item_amount2 =  explode('[end_item_amount]',$item_amount[1]);
			
			$map_item_amount =  explode('[map_item_amount]',str_replace('[]','',$product));
			$map_item_amount2 =  explode('[end_map_item_amount]',$map_item_amount[1]);
			
			$set_amount =  explode('[set_amount]',$product);
			$set_amount2 =  explode('[end_set_amount]',$set_amount[1]);
			
			if($item_name2[0])
				{
				$set_value = 0;
				$set_item_quantity = 0;
				if($set_amount2[0] == 'map' && $form_data[$map_item_amount2[0]])
					{
					
					if($set_quantity2[0] == 'map' && $form_data[$map_item_qty2[0]])
						$set_item_quantity = $form_data[$map_item_qty2[0]];
					if($set_quantity2[0] == 'static' && $item_qty2[0])
						$set_item_quantity = $item_qty2[0];
					
					if(is_array($form_data[$map_item_amount2[0]]) && !empty($form_data[$map_item_amount2[0]]))
						{
						foreach($form_data[$map_item_amount2[0]] as $value)
							$set_value += str_replace(',','',$value);
						}
					else
						$set_value = str_replace(',','',$form_data[$map_item_amount2[0]]);
					

					$item_total += ($set_value * $set_item_quantity);
					if($item_name2[0]!='')
						{
						$item[$index] = new \PayPal\Api\Item();
						$item[$index]->setName($item_name2[0]);
						$item[$index]->setCurrency($get_result->currency_code);
						$item[$index]->setQuantity($set_item_quantity);
						
						$decimal = (!strstr($set_value,'.')) ? '.00' : '';
						
						$item[$index]->setPrice($set_value.$decimal);
						$items[] = $item[$index];
						$index++;
						}
					
					
					}
				elseif($set_amount2[0] == 'static' && $item_amount2[0])
					{
					
					if($set_quantity2[0] == 'map' && $form_data[$map_item_qty2[0]])
						$set_item_quantity = $form_data[$map_item_qty2[0]];
					if($set_quantity2[0] == 'static' && $item_qty2[0])
						$set_item_quantity = $item_qty2[0];

					$item_total += ($item_amount2[0] * $set_item_quantity);
					if($item_name2[0]!='')
						{
						$item[$index] = new \PayPal\Api\Item();
						$item[$index]->setName($item_name2[0]);
						$item[$index]->setCurrency($get_result->currency_code);
						$item[$index]->setQuantity($set_item_quantity);
						
						$decimal = (!strstr($item_amount2[0],'.')) ? '.00' : '';
						
						$item[$index]->setPrice($item_amount2[0].$decimal);
						$items[] = $item[$index];
						$index++;
						}
					
					}
				
				}	
			}
			
	$itemList = new \PayPal\Api\ItemList();
	$itemList->setItems($items); 
	
	
	// ### Additional payment details
	// Use this optional field to set additional
	// payment information such as tax, shipping
	// charges etc.
	$details = new \PayPal\Api\Details();
	$details->setShipping(0)
		->setTax(0)
		->setSubtotal($item_total);
	
	// ### Amount
	// Lets you specify a payment amount.
	// You can also specify additional details
	// such as shipping, tax.
	$amount = new \PayPal\Api\Amount();
	$amount->setCurrency($get_result->currency_code)
		->setTotal($item_total)
		->setDetails($details);
	
	// ### Transaction
	// A transaction defines the contract of a
	// payment - what is the payment for and who
	// is fulfilling it. 
	$transaction = new \PayPal\Api\Transaction();
	$transaction->setAmount($amount)
		->setItemList($itemList)
		->setDescription("Payment description")
		->setInvoiceNumber(uniqid());
	
	// ### Redirect urls
	// Set the urls that the buyer must be redirected to after 
	// payment approval/ cancellation.
	$baseUrl = $return_url;
	$redirectUrls = new \PayPal\Api\RedirectUrls();
	$redirectUrls->setReturnUrl("$baseUrl?success=true&nf-paypal-transaction=1")
		->setCancelUrl("$baseUrl?success=false&nf-paypal-transaction=1");
	
	//Language settings dont work
	/*try {
        $presentation = new \PayPal\Api\Presentation();
        $presentation->setLocaleCode($get_result->lc);

        $webProfile = new \PayPal\Api\WebProfile();
        $webProfile->setName(uniqid())
            ->setPresentation($presentation);

        $createProfileResponse = $webProfile->create($apiContext);
        $profileId = $createProfileResponse->getId();
    } catch (\Exception $ex) { echo $ex; }*/
	/*$set_invoice = new PayPal\Api\Invoice(); 
	$invoiceId = $set_invoice->getId();
	try {
		$invoice = $set_invoice->get($invoiceId, $apiContext);
	} catch (Exception $ex) {
		// NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY
		echo "Get Invoice Invoice".$invoiceId.$ex;
		exit(1);
	}
	// NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY
	 //ResultPrinter::printResult("Get Invoice", "Invoice", $invoice->getId(), $invoiceId, $invoice);
	echo 'Invoice'.$invoice;*/
	
	// ### Payment
	// A Payment Resource; create one using
	// the above types and intent set to 'sale'
	$payment = new \PayPal\Api\Payment();
	$payment->setIntent("sale")
		->setPayer($payer)
		->setRedirectUrls($redirectUrls)
		->setTransactions(array($transaction));
	
	
	// For Sample Purposes Only.
	$request = clone $payment;
	
	// ### Create Payment
	// Create a payment by calling the 'create' method
	// passing it a valid apiContext.
	// (See bootstrap.php for more on `ApiContext`)
	// The return object contains the state and the
	// url to which the buyer must be redirected to
	// for payment approval
	
	try {
		$payment->create($apiContext);
		return array('approval_link'=>$payment->getApprovalLink(), 'payment_id'=>$payment->getId(),'payment_token'=>$payment->getToken(),'payment_ammount'=>$item_total, 'payment_currency'=>$get_result->currency_code,'invoice_id'=>$transaction->invoice_number);
	
	}
	catch (\PayPal\Exception\PayPalConnectionException $ex) {
		// This will print the detailed information on the exception.
		//REALLY HELPFUL FOR DEBUGGING
		return $ex->getData();
	}
	
	
}


	
class NEXForms_paypal{
	public function paypal_payment_status($payment_status){
		
		if(is_array($payment_status))
				$get_payment_status = $payment_status[0];
				
		if(	$get_payment_status=='pending')	
			return '<span class="payment-status txt-orange" title="Pending"><span class="fa fa-clock-o txt-blue-gray"></span></span>';
		if(	$get_payment_status=='failed')	
			return '<span class="payment-status txt-red" title="Failed"><span class="fa fa-close txt-red"></span> </span>';
		if(	$get_payment_status=='payed')	
			return '<span class="payment-status  txt-light-green" title="Payed"><span class="fa fa-check txt-light-green"></span> </span>';
	}
}

function nf_not_found_notice_ppp() {
    
		if(!function_exists('NEXForms_ui_output'))
			{
			?>
			<div class="error notice">
				<p><?php _e( '<strong>NEX-Forms not installed!</strong> You just installed <strong>PayPal PRO Add-on for NEX-Forms</strong>. You need the NEX-Forms core plugin to run this add-on! Please get and install <a href="https://codecanyon.net/item/nexforms-the-ultimate-wordpress-form-builder/7103891?ref=Basix&ad=ppp">NEX-Forms - The Ultimate WordPress Form Builder</a>  OR <a href="https://elements.envato.com/wordpress/nex-forms+lite">NEX-Forms - LITE from Envato Elements</a> to enable the features of this add-on.', 'my_plugin_textdomain' ); ?></p>
			</div>
			<?php
			}
		
}
add_action( 'admin_notices', 'nf_not_found_notice_ppp' );


?>